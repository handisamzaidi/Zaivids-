import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.zaivids.mobile',
  appName: 'Zaivids',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
