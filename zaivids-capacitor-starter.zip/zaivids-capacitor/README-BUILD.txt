# Zaivids Android (Capacitor starter)

This package contains the supplied Zaivids HTML as `www/index.html` and a Capacitor Android project setup.

## What this package is
It is a starter project for creating an Android APK. It is **not itself an APK**. An Android build environment is needed to generate the APK.

## Build requirements
- A computer (Windows, macOS, or Linux)
- Node.js LTS and npm
- Android Studio with the Android SDK installed

## Build steps
1. Extract this ZIP.
2. Open a terminal in the extracted `zaivids-capacitor` folder.
3. Run: `npm install`
4. Run: `npx cap add android`
5. Run: `npx cap sync android`
6. Run: `npx cap open android`
7. In Android Studio, allow Gradle/SDK setup to finish.
8. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
9. Android Studio will show the generated APK location. Share that APK privately with testers.

## Important notes
- The existing HTML design and app code have been copied unchanged into `www/index.html`.
- Supabase and Audius remain loaded by the existing HTML; the phone needs internet access for those online features.
- Never put a Supabase service-role/secret key in this HTML. A public anon/publishable key is intended for client apps, with proper Row Level Security and storage policies enforced in Supabase.
- Before sharing, test sign-up/login, media upload, feed loading, likes/comments, and playback on a real Android device.
- If the app uses browser-only APIs or external links, test those inside the Android WebView; some behaviors may need Capacitor plugins or small compatibility adjustments.
- This starter does not yet add push notifications, native sharing integrations, or offline media storage.
